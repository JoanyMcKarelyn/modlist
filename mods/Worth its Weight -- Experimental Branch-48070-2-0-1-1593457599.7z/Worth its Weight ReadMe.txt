Worth its Weight: Gold Weight via MWSE
Version 2.0.1
By JaceyS

====Requirements====

- Morrowind
- Tribunal
- Bloodmoon
- MGE XE 0.10.1
- MWSE 2.1+

This mod requires a recent nightly build of MWSE. Please be sure to run the mwse-update.exe before playing this mod.

====Description====

By implementing gold weight using MWSE Lua, this mod works reliably without the need for dummy items or burden spell effects. It is also able to show the weight of a stack of gold in the tooltip.

v1.0.1
By cribbing from Merlord, and with the help of OperatorJack, I was able to figure out how to directly update the encumbrance bar, so there is no more dummy item being silently added and removed from the inventory. This is both more elegant, and should help with stability, as I got a crash the other night from the old method.

v1.1
Now works with companions! Note -- companions do not get their gold weight automatically reset when you save. New uninstall directions below.
Tooltip gold weight now works in containers and companions.
Changed the trigger event, so the code should run less often, resulting in more performance. 
Moved player goldweight to the player reference data.

v2.0
Experimental version. Instead of keeping track of gold counts, adds weight to the gold item itself, and then tries to fix all the ways that goes wrong. Mostly works with containers, but the container encumbrance does not update until you close and reopen the container.
Since it works by recalculating what your encumbrance should be based on inventory, and feather and burden effects, it will not work with mods that directly modify encumbrance. I don't know of any that do this except gold weight mods.

v2.0.1
Made the mod only change encumbrance and update the UI when it actually needs to, to try to speed up responsiveness.

===Configuration===
This mod uses the MCM functionality of MWSE to present two configuration options.

Tooltip: Toggle the display of the weight of a stack of gold in the tooltip. Default: On
Gold Weight: How much a single coin weighs. Default: 0.02, which is 50 gold to a pound (or whatever the weight unit is)
Enable
Hard Disable

With this versions, all settings except for Tooltip require you to restart the game.

===Permissions===
You may use the scripting and writing in this mod for any purpose you wish, just give me credit. You have my permission to re-upload this mod in the event that I do not respond to contact on Discord at JaceyS#5136 for a period of 1 week or more. You can send me direct messages if you become a member of the Morrowind Modding Community server.

===Compatibility===
This mod should not be used with other mods that add weight to gold using any method.

If you discover mod incompatibilities, please report them to me on Nexus or at JaceyS#5136 on Discord.

===Issues===
Mostly works with containers, but the container encumbrance does not update until you close and reopen the container.
Negative values put into the Gold Weight field are corrected to positive, but I am sure you could find some other way to break it if you put your mind to it. It should work for reasonable (and most unreasonable) values.

===Installation & Removal===
Installation:
Unpack the archive file such that the top level contents are in your Morrowind\Data Files folder. There is no esp file to activate.

You can load a save file with gold in the inventory with no problems. If converting from another gold weight mod, make sure to follow that mod's instructions for removal.

Removal:
Refer to the files included in the archive file to find what to delete. Also delete Morrowind\Data Files\MWSE\config\WorthItsWeight.json.
If you are not using companions, no special behavior is required to remove this mod from your save, as the gold weight is removed from your character just before you save, and then returned afterwards, or after you load.
If you are using companions, please toggle "Enable" to false in the MCM, then open companion share with all of your companions you have used since installing the mod, and take and replace their gold to reset their encumbrance. After that, you can togle Hard Disable, or uninstall the mod.

==Thanks==
NullCascade, Merlord, Merzasphor, Greatness7, and OperatorJack, for the ongoing development of MWSE.
Kelvin Shadewing, ManaUser, Venombyte, abot, and others, whose goldweight mods have served the community for many years.
WangtorioJackson, for suggesting the name after I discovered that "Burden of Greed" was already taken.